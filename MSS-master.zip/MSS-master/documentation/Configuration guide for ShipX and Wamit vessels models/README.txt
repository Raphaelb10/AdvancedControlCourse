Tutorial on "ShipX and Wamit Vessel Configurations for the HYDRO Toolbox"


It order to use the Hydro Toolbox for processing and plotting of hydrodynamic data computed in ShipX and Wamit, the programs must be configured in a certain way. The document in this folder describes how to configure the inout files of the hydrodynamic codes and how you can load the hydrodynamic data into Matlab.

Thor I. Fossen